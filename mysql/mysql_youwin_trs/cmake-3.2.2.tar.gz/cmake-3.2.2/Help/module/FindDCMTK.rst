.. cmake-module:: ../../Modules/FindDCMTK.cmake
